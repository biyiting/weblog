class UserController {
    async add(ctx, next) {
        // 使用模板引擎中间件在 ctx 上挂载的 render 进行渲染
        await ctx.render('index.html', { name: '张三', age: 11 })
    }
    async remove(ctx, next) {
        await ctx.render('index.html', { name: '删除张三', age: 11 })
    }
}
module.exports = UserController