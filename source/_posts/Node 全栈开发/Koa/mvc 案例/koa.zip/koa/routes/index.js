// 整合
let articleRouter = require('./articleRouter');
let userRouter = require('./userRouter');
let combineRoutes = require('koa-combine-routers');

// 路由合并
module.exports = combineRoutes(articleRouter, userRouter);