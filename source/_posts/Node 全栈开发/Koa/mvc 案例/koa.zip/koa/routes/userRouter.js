let Router = require('koa-router');
let UserController = require('../controller/userController'); // 引入用户的控制器
let user = new UserController();

// 划分路由的作用域，都是以 /user 开头的路由
const router = new Router({ prefix: '/user' });

// 命中路径后 调用对应的控制器来处理
router.get('/add', user.add);
router.get('/remove', user.remove);


module.exports = router;