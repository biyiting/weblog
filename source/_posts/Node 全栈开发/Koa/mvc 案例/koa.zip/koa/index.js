const Koa = require('koa');
const Router = require('koa-router')
const app = new Koa();
const router = require('./routes/index'); // 引入合并后的路由
const views = require('koa-views'); // ejs 模板引擎中间件
const cors = require('koa-cors'); // 跨域中间件

app.use(cors());

// 模板在 /views 下
app.use(views(__dirname + '/views', { // 在 ctx 上新增了一个 render 方法
    map: {
        html: 'ejs' // 内部会自动引入 ejs模板
    }
}));

app.use(router());
app.listen(3000, () => { console.log('locahost:3000') });