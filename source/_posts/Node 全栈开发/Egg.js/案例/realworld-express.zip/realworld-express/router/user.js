const express = require('express')
const userCtrl = require('../controller/user')
const userValidator = require('../validator/user')
const auth = require('../middleware/auth')
const noAuth = require('../middleware/no-auth')

const router = express.Router()

// 展示登录界面
// noAuth 检查有没有 Session user
router.get('/login', noAuth, userCtrl.showLogin)

// 登录成功后跳转到首页
router.post('/login', noAuth, userValidator.login, userCtrl.login)

// 展示注册界面
router.get('/register', noAuth, userCtrl.showRegister)

// 退出
router.get('/logout', userCtrl.logout)

// 注册成功后跳转到首页
router.post('/register', userValidator.register, userCtrl.register)

// 设置界面
// auth 为界面的访问权限（是否登录）
router.get('/settings', auth, userCtrl.showSettings)

// 用户资料
router.get('/profile/:username', userCtrl.showProfile)

// 用户资料
router.get('/profile/:username/favorites', userCtrl.showProfile)

module.exports = router
