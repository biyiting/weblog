<template>
  <div id="nav">
    <!-- /vue => 加载子应用 -->
    <router-link to="/vue">vue项目</router-link>
    <!-- 子应用加载的位置 -->
    <div id="vue"></div>
  </div>
</template>

<style>
</style>
