import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import { registerApplication, start } from "single-spa";
import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
Vue.use(ElementUI);

// 加载 js 脚本，插入到 html 的 head 后
const loadScript = async (url) => {
  await new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = url;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
};

// 注册子应用：registerApplication 第二个参数必须是 promise 函数
registerApplication(
  "singleVue",
  async () => {
    // 加载子应用
    
    await loadScript("http://localhost:10000/js/chunk-vendors.js");
    await loadScript("http://localhost:10000/js/app.js");
    return window.singleVue;
  },
  (location) => location.pathname.startsWith("/vue") // 切换到 /vue 路径下，加载子应用
);
start();

new Vue({
  router,
  render: (h) => h(App),
}).$mount("#app");
