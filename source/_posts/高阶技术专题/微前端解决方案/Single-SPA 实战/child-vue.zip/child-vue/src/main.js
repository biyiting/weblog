import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import singleSpaVue from "single-spa-vue";
Vue.config.productionTip = false;

const appOptions = {
  el: "#vue", // 挂载到父应用的 #vue 上
  router,
  render: (h) => h(App),
};

if (window.singleSpaNavigate) {
  // 被父应用引用
  // 动态设置子应用 publicPath
  // 设置绝对路径，这样就不会自动获取浏览器的 host+ip 去发请求了
  __webpack_public_path__ = "http://localhost:10000/";
} else {
  // 子应用独立运行
  delete appOptions.el;
  new Vue(appOptions).$mount("#app");
}

const vueLifeCycle = singleSpaVue({
  Vue,
  appOptions,
});

// 协议接入：定好了协议，父应用调用
// 子应用必须导出 以下生命周期 bootstrap、mount、unmount
export const bootstrap = vueLifeCycle.bootstrap;
export const mount = vueLifeCycle.mount;
export const unmount = vueLifeCycle.unmount;

export default vueLifeCycle;

// 将子应用打包成 lib 给父应用使用
