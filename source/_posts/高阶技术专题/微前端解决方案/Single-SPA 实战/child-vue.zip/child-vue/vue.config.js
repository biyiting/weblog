// 自定义打包方式
module.exports = {
  configureWebpack: {
    output: {
      library: "singleVue", // 打包成类库，指定名字
      libraryTarget: "umd", // 指定打包模块类型
    },
    devServer: {
      // 配置开发服务
      port: 10000,
    },
  },
};

// 打包成 umd 模块的特点，会把 bootstrap、mount、unmount 挂载到全局上
// window.singleVue.bootstrap
// window.singleVue.mount
// window.singleVue.unmount
