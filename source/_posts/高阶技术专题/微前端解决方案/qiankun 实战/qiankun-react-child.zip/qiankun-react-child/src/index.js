import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";

function render() {
  ReactDOM.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
    document.getElementById("root")
  );
}

if (!window.__POWERED_BY_QIANKUN__) { // 独立运行
  render();
}

export async function bootstrap() {
  // 启动
}
export async function mount() {
  // 挂载
  render();
}
export async function unmount() {
  // 销毁
  ReactDOM.unmountComponentAtNode(document.getElementById("root"));
}
