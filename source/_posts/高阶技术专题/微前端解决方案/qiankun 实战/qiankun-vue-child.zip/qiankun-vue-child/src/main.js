import Vue from "vue";
import App from "./App.vue";
import router from "./router";
Vue.config.productionTip = false;

let instance = null;
function render() {
  instance = new Vue({
    router,
    render: (h) => h(App),
  }).$mount("#app"); // 挂载到自己的 html 中，基座会把挂载后的 html 插入到基座中
}

if (window.__POWERED_BY_QIANKUN__) { // 动态添加 public path
  __webpack_public_path__ = window.__INJECTED_PUBLIC_PATH_BY_QIANKUN__;
}
if (!window.__POWERED_BY_QIANKUN__) { // 独立运行，不作为子应用
  render();
}
export async function bootstrap(props) {
  // 启动
}
export async function mount(props) {
  console.log(props); // 父应用传过来的
  // 挂载
  render();
}
export async function unmount(props) {
  // 销毁
  instance.$destroy();
}
