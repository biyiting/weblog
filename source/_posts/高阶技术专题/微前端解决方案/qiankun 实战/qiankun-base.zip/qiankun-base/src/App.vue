<template>
  <div>
    <el-menu :router="true" mode="horizontal">
      <!-- 基座自己的路由 -->
      <el-menu-item index="/">首页</el-menu-item>
      <!-- 基座 vue 子应用 -->
      <el-menu-item index="/vue">vue应用</el-menu-item>
      <!-- 基座 react 子应用 -->
      <el-menu-item index="/react">react应用</el-menu-item>
    </el-menu>
    <router-view v-show="$route.name"></router-view>
    <div v-show="!$route.name" id="vue"></div>
    <div v-show="!$route.name" id="react"></div>
  </div>
</template>