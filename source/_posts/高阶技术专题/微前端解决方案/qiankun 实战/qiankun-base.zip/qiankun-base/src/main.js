import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
import { registerMicroApps, start } from "qiankun";
Vue.use(ElementUI);
Vue.config.productionTip = false;

// 注册子应用
const apps = [
  {
    name: "vueApp", // 引用名字
    entry: "http://localhost:10000", // 默认会加载这个 html，解析里面的 js，动态执行（子应用必须支持跨域）
    container: "#vue", // 挂载节点 id
    activeRule: "/vue", // 激活的路径
    props: {
      // 自定义属性 传递给 vue 子应用
      a: 1,
      b: 2,
    },
  },
  {
    name: "reactApp",
    entry: "http://localhost:20000",
    container: "#react",
    activeRule: "/react",
  },
];
registerMicroApps(apps);
start();

new Vue({
  router,
  render: (h) => h(App),
}).$mount("#app");
