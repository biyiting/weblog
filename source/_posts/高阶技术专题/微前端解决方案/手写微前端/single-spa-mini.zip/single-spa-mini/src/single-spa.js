export { registerApplication } from "./applications/app.js";
export { start } from "./start.js";
