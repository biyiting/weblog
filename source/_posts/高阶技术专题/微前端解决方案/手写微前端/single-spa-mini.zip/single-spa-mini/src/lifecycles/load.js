import {
  LOADING_SOURCE_CODE,
  NOT_BOOTSTRAPPED,
  NOT_LOADED,
} from "../applications/app.helpers";

// 将 promise[] 通过 then 链转成一个 promise（类似函数扁平化，koa、redux 都是这种写法）
function flattenFnArray(fns) {
  // 将函数通过 then 链连接起来
  fns = Array.isArray(fns) ? fns : [fns];
  return function (props) {
    return fns.reduce((p, fn) => p.then(() => fn(props)), Promise.resolve());
  };
}

/**
 * 加载 app 实例
 * @param {*} app
 * @returns
 */
export async function toLoadPromise(app) {
  // 给 app 加载时做一个缓存处理，当 loadPromise 有值，说明已经加载过了（避免重复加载）
  if (app.loadPromise) return app.loadPromise; // 缓存机制

  // 如果资源加载过，直接 return
  if (app.status !== NOT_LOADED) return app;

  app.status = LOADING_SOURCE_CODE; // 加载资源
  return (app.loadPromise = Promise.resolve().then(async () => {
    let { bootstrap, mount, unmount } = await app.loadApp(app.customProps); // 调用 load 函数拿到接入协议

    app.status = NOT_BOOTSTRAPPED;
    app.bootstrap = flattenFnArray(bootstrap);
    app.mount = flattenFnArray(mount);
    app.unmount = flattenFnArray(unmount);
    delete app.loadPromise;
    return app;
  }));
}
