import { UNMOUNTING, NOT_MOUNTED, MOUNTED } from "../applications/app.helpers";

export async function toUnmountPromise(app) {
  // 当前应用没有被挂载，什么都不用做
  if (app.status != MOUNTED) return app;

  app.status = UNMOUNTING; // 卸载中
  await app.unmount(app); // 卸载
  app.status = NOT_MOUNTED; // 卸载完毕

  return app;
}
