import { MOUNTED, MOUNTING, NOT_MOUNTED } from "../applications/app.helpers.js";

export async function toMountPromise(app) {
  if (app.status !== NOT_MOUNTED) return app;

  app.status = MOUNTING; // 挂载中
  await app.mount(); // 挂载
  app.status = MOUNTED; // 挂载完毕

  return app;
}
