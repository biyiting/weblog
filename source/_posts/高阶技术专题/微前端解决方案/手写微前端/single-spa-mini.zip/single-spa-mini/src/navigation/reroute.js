import { getAppChanges } from "../applications/app.js";
import { started } from "../start.js";
import { toLoadPromise } from "../lifecycles/load";
import { toUnmountPromise } from "../lifecycles/unmount";
import { toBootstrapPromise } from "../lifecycles/bootstrap";
import { toMountPromise } from "../lifecycles/mount";
import "./navigator-events";

export function reroute() {
  const {
    appsToLoad, // 获取要去加载的 app
    appsToMount, // 获取要被挂载的 app
    appsToUnmount, // 获取要被卸载的 app
  } = getAppChanges();

  // start 方法调用是同步的，loadApps 加载流程是异步的
  if (started) {
    return performAppChanges(); // app 装载
  } else {
    return loadApps(); //注册应用的时候需要预加载
  }

  // 预加载应用
  async function loadApps() {
    let apps = await Promise.all(appsToLoad.map(toLoadPromise)); // 获取到 bootstrap、mount、unmount 放到 app 上
    console.log(apps);
  }

  // 根据路径装载应用
  async function performAppChanges() {
    // 先卸载不需要的应用（并发处理）
    let unmountPromise = appsToUnmount.map(toUnmountPromise);
    // 加载需要的应用
    appsToLoad.map(async (app) => {
      app = await toLoadPromise(app); // 加载
      app = await toBootstrapPromise(app); // 启动
      return await toMountPromise(app); // 挂载
    });
    appsToMount.map(async (app) => {
      app = await toBootstrapPromise(app); // 启动
      return await toMountPromise(app); // 挂载
    });
  }
}
