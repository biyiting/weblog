import {
  BOOTSTRAPPING,
  NOT_MOUNTED,
  NOT_BOOTSTRAPPED,
} from "../applications/app.helpers.js";

export async function toBootstrapPromise(app) {
  // 说明还没有启动
  if (app.status !== NOT_BOOTSTRAPPED) return app;

  app.status = BOOTSTRAPPING; // 加载中
  await app.bootstrap(app.customProps); // 加载
  app.status = NOT_MOUNTED; // 加载完毕

  return app;
}
