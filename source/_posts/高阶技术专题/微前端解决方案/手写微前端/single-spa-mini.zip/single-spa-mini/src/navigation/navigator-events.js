import { reroute } from "./reroute.js";

export const routingEventsListeningTo = ["hashchange", "popstate"];
// 存储 hashchang 和 popstate 注册的方法
const capturedEventListeners = {
    hashchange: [],
    popstate: [], // 应用切换完成后调用
};

function urlReroute() {
    reroute(); // 根据路径重新加载不同的应用
}
// 监听 hash 变化
window.addEventListener("hashchange", urlReroute); 
// 监听 history 路由变化（pushState 和 repalceState 不会触发）
window.addEventListener("popstate", urlReroute); 

// 利用 aop 面相切面编程的思想，重写 addEventListener、removeEventListener（添加一些自定义的逻辑）
const originalAddEventListener = window.addEventListener;
const originalRemoveEventListener = window.removeEventListener;
// 重写 addEventListener、removeEventListener 方法
window.addEventListener = function (eventName, fn) {
    if (
        routingEventsListeningTo.includes(eventName) &&
        !capturedEventListeners[eventName].some((listener) => listener == fn)
    ) {
        capturedEventListeners[eventName].push(fn);
        return;
    }
    return originalAddEventListener.apply(this, arguments);
};
window.removeEventListener = function (eventName, listenerFn) {
    if (routingEventsListeningTo.includes(eventName)) {
        capturedEventListeners[eventName] = capturedEventListeners[
            eventName
        ].filter((fn) => fn !== listenerFn);
        return;
    }
    return originalRemoveEventListener.apply(this, arguments);
};


function patchedUpdateState(updateState) {
    return function () {
        const urlBefore = window.location.href;
        const result = updateState.apply(this); // 调用切换路由方法
        const urlAfter = window.location.href;

        // 路由变化，重新加载应用
        if (urlBefore !== urlAfter) urlReroute();

        return result;
    };
}

// history路由，hash 变化时不会触发 popstate
// 重写 pushState 和 repalceState 方法，让 hash 变化 history 可以触发 popstate
window.history.pushState = patchedUpdateState(window.history.pushState);
window.history.replaceState = patchedUpdateState(window.history.replaceState);