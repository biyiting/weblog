import { reroute } from "../navigation/reroute.js";
import {
  shouldBeActive,
  SKIP_BECAUSE_BROKEN,
  NOT_LOADED,
  LOADING_SOURCE_CODE,
  NOT_BOOTSTRAPPED,
  NOT_MOUNTED,
  MOUNTED,
} from "./app.helpers.js";

const apps = [];

/**
 * 注册应用，维护应用的状态（状态机）
 * @param {*} appName 当前注册应用的名字
 * @param {*} loadApp 加载函数(必须返回的是promise)，返回的结果必须包含bootstrap、mount和 unmount做为接入协议
 * @param {*} activeWhen 满足条件时调用 loadApp 方法
 * @param {*} customProps 自定义属性可用于父子应用通信
 */
export function registerApplication(appName, loadApp, activeWhen, customProps) {
  apps.push({
    name: appName,
    loadApp,
    activeWhen,
    customProps,
    status: NOT_LOADED, // 默认应用为未加载
  });

  reroute(); // 这个是加载应用
}

/**
 * 获取 app 的状态
 * @returns {
 *  appsToLoad: "获取要去加载的 app", 
 *  appsToMount: "获取要被挂载的 app", 
 *  appsToUnmount: "获取要被卸载的 app"
 * }
 */
export function getAppChanges() {
  const appsToUnmount = []; // 获取要被卸载的 app
  const appsToLoad = []; // 获取要去加载的 app
  const appsToMount = []; // 获取要被挂载的 app

  apps.forEach((app) => {
    // 是否需要被加载
    const appShouldBeActive =
      app.status !== SKIP_BECAUSE_BROKEN && shouldBeActive(app);
    switch (app.status) {
      case NOT_LOADED: // 没有被加载
      case LOADING_SOURCE_CODE: // 没有被加载
        if (appShouldBeActive) {
          appsToLoad.push(app);
        }
        break;
      case NOT_BOOTSTRAPPED: // 没有被挂载
      case NOT_MOUNTED: // 没有被加载
        if (appShouldBeActive) {
          appsToMount.push(app);
        }
        break;
      case MOUNTED: // 已经被挂载
        if (!appShouldBeActive) {
          appsToUnmount.push(app);
        }
    }
  });

  return { appsToUnmount, appsToLoad, appsToMount };
}
