import serve from "rollup-plugin-serve";

// 只借助 rollup 模块化和打包的能力~，不进行过多的 rollup 配置
export default {
  input: "./src/single-spa.js",
  output: {
    file: "./lib/umd/single-spa.js",
    format: "umd", // 默认会挂载到 window 上
    name: "singleSpa", // 挂载到 window 上的名字
    sourcemap: true,
  },
  plugins: [
    serve({
      openPage: "/index.html",
      contentBase: "",
      port: 4000,
    }),
  ],
};