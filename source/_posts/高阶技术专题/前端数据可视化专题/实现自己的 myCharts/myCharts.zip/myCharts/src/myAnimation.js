export default function myAnimation(param) {
  let current = 0
  let looped
  // 获取上下文
  const ctx = this.ctx
  // 获取画布
  const _canvas = this._canvas
  // 渲染函数
  const callback = param.render
  // 成功回调
  const successCb = param.success;

  (function looping() {
    looped = requestAnimationFrame(looping)
    if (current < param.percent) {
      // 清空画布
      ctx.clearRect(0, 0, _canvas.width, _canvas.height)
      // 改变current的值，动画时间的变化
      current = current + 4 > param.percent ? param.percent : current + 4
      // 执行渲染函数
      callback(current)
    } else {
      window.cancelAnimationFrame(looping)
      looped = null
      successCb && successCb()
    }
  })()
}