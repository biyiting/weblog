let Cirque = function (percent) {

  const ctx = this.ctx
  const circleConfig = this.defaultParam

  // 绘制打底圆环
  ctx.beginPath()
  ctx.lineWidth = circleConfig.arcWidth
  // 放射性渐变 第一个圆环的坐标和半径，第二个圆环的坐标和半径
  let grd = ctx.createRadialGradient(circleConfig.x, circleConfig.y, circleConfig.radius - 10, circleConfig.x, circleConfig.y, circleConfig.radius + 10)
  // 渐变颜色
  grd.addColorStop(0, "#e9eae9")
  grd.addColorStop("0.8", "#fefefe")
  grd.addColorStop("1", "#e9eae9")
  // 绘制样式
  ctx.strokeStyle = grd
  // 绘制圆环 圆心坐标、半径、开始角度、结束角度、默认为顺时针
  ctx.arc(circleConfig.x, circleConfig.y, circleConfig.radius, circleConfig.startAngle, circleConfig.endAngle)
  ctx.stroke()
  ctx.closePath()

  // 绘制进度圆环
  ctx.beginPath()
  ctx.lineWidth = circleConfig.arcWidth
  // 放射性渐变 第一个圆环的坐标和半径，第二个圆环的坐标和半径
  let linear = ctx.createLinearGradient(220, 220, 380, 200)
  linear.addColorStop(0, '#ffc26b')
  linear.addColorStop(0.5, '#ff9a5f')
  linear.addColorStop(1, '#ff8157')
  // 绘制样式
  ctx.strokeStyle = linear
  // 绘制圆环 圆心坐标、半径、开始角度、结束角度、默认为顺时针
  ctx.arc(circleConfig.x, circleConfig.y, circleConfig.radius, circleConfig.startAngle, circleConfig.endAngle * percent)
  ctx.stroke()
  ctx.closePath()

  // 起点的圆形
  ctx.beginPath()
  ctx.fillStyle = '#ff7854'
  // 绘制圆环 圆心坐标、半径、开始角度、结束角度、默认为顺时针
  ctx.arc(circleConfig.x + circleConfig.radius, circleConfig.y - 1, circleConfig.arcWidth / 2, circleConfig.startAngle, circleConfig.endAngle)
  ctx.fill()
  ctx.closePath()

  // 终点的圆形
  ctx.beginPath()
  ctx.lineWidth = circleConfig.arcWidth - 10
  ctx.fillStyle = '#fff'
  ctx.strokeStyle = '#ff7854'
  // 转动后的 x 坐标
  let tarX = circleConfig.x + circleConfig.radius * Math.cos(2 * Math.PI * percent)
  // 转动后的 y 坐标
  let tarY = circleConfig.y + circleConfig.radius * Math.sin(2 * Math.PI * percent)
  // 绘制圆环 圆心坐标、半径、开始角度、结束角度、默认为顺时针
  ctx.arc(tarX, tarY, circleConfig.arcWidth - 8, circleConfig.startAngle, circleConfig.endAngle)
  // 圆环填充
  ctx.fill()
  // 圆环描边
  ctx.stroke()
  ctx.closePath()

}

export default Cirque