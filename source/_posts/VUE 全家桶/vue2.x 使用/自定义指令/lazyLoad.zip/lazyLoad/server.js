const express = require('express');
const app = express();
app.use(express.static(__dirname))
app.listen(4500);

const arr = [];
for (let i = 10; i <= 20; i++) {
    arr.push(`http://localhost:4500/images/${i}.jpeg`)
}

app.get('/api/img', (req, res) => {
    res.json(arr)
})


