import createApp from './app';
const { app } = createApp();
app.$mount('#app');