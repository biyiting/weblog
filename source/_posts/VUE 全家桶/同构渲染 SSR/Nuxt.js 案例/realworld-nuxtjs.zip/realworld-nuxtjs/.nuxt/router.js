import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _a0375194 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _1e8c382a = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _26bae1dd = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _3cb0af1d = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _2ab575a2 = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _b7d5050e = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _237af26a = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _a0375194,
    children: [{
      path: "",
      component: _1e8c382a,
      name: "home"
    }, {
      path: "/login",
      component: _26bae1dd,
      name: "login"
    }, {
      path: "/register",
      component: _26bae1dd,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _3cb0af1d,
      name: "profile"
    }, {
      path: "/settings",
      component: _2ab575a2,
      name: "settings"
    }, {
      path: "/editor",
      component: _b7d5050e,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _237af26a,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
