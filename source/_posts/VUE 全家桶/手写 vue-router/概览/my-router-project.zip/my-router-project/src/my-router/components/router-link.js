export default {
  name: 'router-link',
  functional: true, // 函数式组件，函数不用 new，没有 this，没有生命周期，没有数据 data 
  props: {
    to: {
      type: String,
      required: true
    },
    tag: {
      type: String
    }
  },
  render(h, context) {
    let tag = context.tag || 'a';
    const clickHandler = () => { // 指定跳转方法
      context.parent.$router.push(context.props.to);
      // 调用 $router 中的 push 方法进行跳转
    }
    return h(tag, {
      on: {
        click: clickHandler
      },
    }, context.slots().default);
  }
}

