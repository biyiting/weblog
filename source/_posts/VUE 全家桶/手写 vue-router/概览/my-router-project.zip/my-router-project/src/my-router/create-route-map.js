const addRouteRecord = (route, pathList, pathMap, parentRecord) => {
    // 多层级路由时，做拼接
    let path = parentRecord ? `${parentRecord.path}/${route.path}` : route.path;

    // 根据当前路由产生一个记录 path/component
    let record = { path, component: route.component, parent: parentRecord /* 记录父路径 */ };

    // 防止用户编写路由时有重复的，不去覆盖
    if (!pathMap[path]) {
        pathMap[path] = record;
        pathList.push(path);
    }

    /// 要将子路由也放到对应的 pathMap 和 pathList
    if (route.children) {
        route.children.forEach(r => {
            addRouteRecord(r, pathList, pathMap, record);
        });
    }
}

// 具备初始化和新增的功能
function createRouteMap(routes, oldPathList, oldPathMap) {
    let pathList = oldPathList || [];
    let pathMap = oldPathMap || {};
    routes.forEach(route => { addRouteRecord(route, pathList, pathMap) });

    return { pathList, pathMap };
}

export default createRouteMap;