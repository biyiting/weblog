import History from './base';

const ensureSlash = () => {
    // window.location.href.slice('#')[1]
    if (window.location.hash) {
        return;
    }
    window.location.hash = '/';
}

export default class HashHistory extends History {
    constructor(router) {
        super(router);
        this.router = router;
        ensureSlash(); // 如果没有 hash 值，应该跳转到 首页 #/
    }
    getCurrentLocation() {
        return window.location.hash.slice(1);
    }
    setupListener() {
        window.addEventListener('hashchange', () => {
            // 再次执行匹配操作
            this.transitionTo(this.getCurrentLocation())
        })
    }
}