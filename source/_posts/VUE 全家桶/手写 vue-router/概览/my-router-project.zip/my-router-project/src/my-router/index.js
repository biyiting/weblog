import install from './install';
import createMatcher from './create-matcher';
import HashHistory from './history/hashHistory';
import BrowserHistory from './history/browserHistory';

class VueRouter {
    constructor(options) {
        // 1.接收 RouterOptions

        // 2.创建匹配器的过程，并返回 match, addRoutes 方法
        // match函数：匹配功能
        // addRoutes函数：可以添加匹配，动态路由添加
        this.matcher = createMatcher(options.routes || []);

        // 3.创建路由模式，默认值是 hash 模式
        this.mode = options.mode || 'hash';
        switch (this.mode) {
            case 'hash':
                this.history = new HashHistory(this)
                break;
            case 'history':
                this.history = new BrowserHistory(this);
                break;
        }

        // 4.初始化钩子队列（这里只初始化 beforeHooks）
        this.beforeHooks = [];
    }
    match(location) {
        return this.matcher.match(location);
    }
    init(app) { // 目前这个 app 指代的就是最外层 new Vue 根实例
        // 需要根据用户配置，做出一个映射表
        // 需要根据当前路径，实现页面跳转的逻辑

        const history = this.history;

        // 进行匹配操作，根据路径获取对应的记录
        let setupHashListener = () => {
            history.setupListener(); // 设置 hashchange 监听事件
        }
        // 根据 history（hash、browser）类型，调用 transitionTo 跳转到不同的初始页面
        history.transitionTo(history.getCurrentLocation(), setupHashListener)

        // 注册 updateRoute 回调，在 router 更新时，更新 app._route 完成页面重新渲染
        history.listen((route) => {
            app._route = route; 
        })
    }
    push(location) {
        const history = this.history;
        window.location.hash = location;
    }
    beforeEach(fn) {
        this.beforeHooks.push(fn);
    }
}

VueRouter.install = install;

export default VueRouter;





