import History from './base';

export default class BrowserHistory extends History {

}