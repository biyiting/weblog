import Vue from 'vue';
import App from './App.vue'; // App => new Vue.extend({component,name,render})
import router from './router/index'

new Vue({
  el: '#app',
  render: h => h(App),
  router // 这里让所有子组件都可以获取到router属性
});

