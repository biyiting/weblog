import createRouteMap from './create-route-map'
import { createRoute } from './history/base'

export default function createMatcher(routes) {
    // 动态添加路由 规则就是 404 首页 所有人都能看到 先配好了
    // 登录了 =》 再将对应的权限 和之前的进行一个组合  (菜单全选 路由权限)

    // routes 是用户自己配置的，但是用起来不方便，利用 createRouteMap 生成 pathList、pathMap
    //  pathList：把所有的路由t，组成一个数组 => ['/', '/about', '/about/a', '/about/b', '/xxx']
    //  pathMap ：把所有的路由，组成一个map => { '/': { }, '/about': { }, '/about/a': { } }
    let { pathList, pathMap } = createRouteMap(routes);

    // 通过用户输入路径，获取对应的匹配记录
    function match(location) {
        let record = pathMap[location];// 获取对应的记录
        // /about/a  => matched:[/about,/a]
        return createRoute(record, { path: location })
    }

    // 动态格式化路由
    function addRoutes(routes) {
        // routes 动态添加的路由
        createRouteMap(routes, pathList, pathMap)
    }

    return { match, addRoutes };
}

