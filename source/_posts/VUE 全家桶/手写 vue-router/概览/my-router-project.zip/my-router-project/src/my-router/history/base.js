// 根据匹配到的记录来计算匹配到的所有的记录  
export const createRoute = (record, location) => {
    let matched = []
    if (record) {
        while (record) {
            matched.unshift(record);
            record = record.parent; // 通过当前记录找到所有的父亲 
        }
    }

    // {path:'/',matched:[{}]}
    return { ...location, matched };
}

const runQueue = (queue, iterator, complete) => {
    function next(index) {
        if (index >= queue.length) {
            return complete();
        }
        let hook = queue[index]; // 取出hook钩子函数
        iterator(hook, () => next(index + 1)); // 就是遍历的过程
    }
    next(0);
}

// 这个current就是一个普通的变量，希望current变化了可以更新视图，
export default class History {
    constructor(router) {
        this.router = router;

        // 这个代表的是，当前路径匹配出来的记录
        // /about/a 匹配=> {path:'/about',component:about}、{path:'/about/A',component:A}
        // this.current = {path:'/',matched:[]}
        this.current = createRoute(null, { path: '/' }); // 默认值
    }
    transitionTo(location, complete) {
        // 获取当前路径匹配出对应的记录，当路径变化时获取对应的记录 => 渲染页面 （router-view实现的）
        // 通过路径拿到对应的记录，有了记录之后，就可以找到对象的匹配
        // 当路径变化后 current 属性会进行更新操作
        let current = this.router.match(location);

        // 防止重复点击 不需要再次渲染
        // 匹配到的个数和路径都是相同的，就不需要再次跳转了
        if (this.current.path == location && this.current.matched.length === current.matched.length) {
            return;
        }

        let queue = this.router.beforeHooks; // 钩子函数队列
        const iterator = (hook, next) => { hook(current, this.current, next) };
        runQueue(queue, iterator, () => {
            this.current = current; // 这个 current 只是响应式的，他的变化不会更新 _route
            this.cb && this.cb(current); // 手动更新 _route 的回调函数
            complete && complete(); // 监听浏览器 url 变化的事件的初始化函数
        });
    }
    listen(cb) { // 保存回调函数
        this.cb = cb;
    }
}