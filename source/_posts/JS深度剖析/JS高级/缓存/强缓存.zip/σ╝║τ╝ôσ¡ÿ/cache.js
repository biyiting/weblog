const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');

http.createServer((req, res) => {
    const { pathname } = url.parse(req.url);
    const filePath = path.join(__dirname, pathname);

    // 兼容老版本浏览器（绝对时间，这个时间前取缓存） 
    res.setHeader('Expires', new Date(Date.now() + 10 * 1000).toGMTString());
    // 新版本浏览器（相对时间，10秒内取缓存，优先级比 Expires 高）
    res.setHeader('Cache-Control', 'max-age=10');


    // res.setHeader('Cache-Control','no-cache'); // 缓存但是每次都会发请求
    // res.setHeader('Cache-Control','no-store'); // 不在浏览器中进行缓存，每次请求服务器、


    // 问题：强制缓存不会像服务器发送请求，会导致页面样式修改后，视图依旧采用老的
    fs.stat(filePath, (err, statObj) => {
        if (err) return res.statusCode = 404, res.end('Not Found');
        if (statObj.isFile()) {
            fs.createReadStream(filePath).pipe(res);
        } else {
            res.statusCode = 404, res.end('Not Found');
        }
    })
}).listen(3000);

// 访问地址：http://localhost:3000/public/index.html