const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');

http.createServer((req, res) => {
    const { pathname } = url.parse(req.url);
    const filePath = path.join(__dirname, pathname);

    // 设置过期时间缓存策略
    res.setHeader('Cache-Control', 'no-Cache');
    let ifModifiedSince = req.headers['if-modified-since'];

    fs.stat(filePath, (err, statObj) => {
        if (err) return res.end();

        // 过期时间缓存策略验证
        let LastModified = statObj.ctime.toGMTString();
        if (ifModifiedSince === LastModified) {
            res.statusCode = 304;
            return res.end();
        }
        res.setHeader('Last-Modified', LastModified);

        if (err) return res.statusCode = 404, res.end('Not Found');
        if (statObj.isFile()) {
            fs.createReadStream(filePath).pipe(res);
        } else {
            res.statusCode = 404, res.end('Not Found');
        }
    })
}).listen(3000);

// 访问地址：http://localhost:3000/public/index.html
