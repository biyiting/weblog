if (!/pnpm/.test(process.env.npm_execpath || '')) {
    // 当 install 的时候调用这个脚本
    console.log(`\u001b[33m----------\u001b[39m\n`);
    console.warn(`\u001b[33mThis repository requires using pnpm as the package managerfor scripts to work properly.\u001b[39m\n`);
    console.warn(`\u001b[33mThis repository requires using pnpm as the package managerfor scripts to work properly.\u001b[39m\n`);
    console.warn(`\u001b[33mThis repository requires using pnpm as the package managerfor scripts to work properly.\u001b[39m\n`);
    console.log(`\u001b[33m----------\u001b[39m\n`);
    process.exit(1);
}

