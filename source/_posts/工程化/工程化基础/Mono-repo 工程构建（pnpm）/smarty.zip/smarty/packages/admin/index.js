const str = require('@smarty-admin/utils')
// 等价
// const str = require('../utils')
console.log(str); // I am Utils......